# RBAC-IN-PHP
使用php实现的一个rbac权限管理微型系统
