<?php include "checkPermission.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>pageThree</title>
</head>
<body>
    <h1>pageThree</h1>
    <input type="button" onclick="history.back()" value="返回">
</body>
</html>