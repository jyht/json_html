<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
</head>
<body>
    <h2><a href="./pageone.php">pageone.php</a></h2>
    <h2><a href="./pagetwo.php">pagetwo.php</a></h2>
    <h2><a href="./pagethree.php">pagethree.php</a></h2>
</body>
</html>
<br><br><br><hr>
<h1 style="color:red">
注意：<br>
&nbsp;&nbsp;&nbsp;&nbsp;为了减少代码，模拟登陆的方式：修改/rbac/frontend/checkPermission.php中的user_id和user_name<br>
&nbsp;&nbsp;&nbsp;&nbsp;修改用户之后即可正常测试。
</h1>