<?php include "checkPermission.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>pageOne</title>
</head>
<body>
    <h1>pageOne</h1>
    <input type="button" onclick="history.back()" value="返回">
</body>
</html>